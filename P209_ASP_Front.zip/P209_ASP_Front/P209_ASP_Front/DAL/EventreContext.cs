﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using P209_ASP_Front.Models;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace P209_ASP_Front.DAL
{
    public class EventreContext : DbContext
    {
        public EventreContext() : base("EventreContext")
        {
        }

        public DbSet<Header> Headers { get; set; }
        public DbSet<About> About { get; set; }
        public DbSet<Speaker> Speakers { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Talk> Talks { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }
}