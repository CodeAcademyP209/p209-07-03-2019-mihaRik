namespace P209_ASP_Front.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedThumbImages : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Speaker", "ImageThumb", c => c.String(nullable: false, maxLength: 300));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Speaker", "ImageThumb");
        }
    }
}
