﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P209_ASP_Front.DAL;
using P209_ASP_Front.Models;
using P209_ASP_Front.Models.ViewModels;

namespace P209_ASP_Front.Controllers
{
    public class HomeController : Controller
    {
        private readonly EventreContext _context;

        public HomeController()
        {
            _context = new EventreContext();
        }

        public ActionResult Index()
        {
            var vm = new HomeIndexVM
            {
                Header = _context.Headers.First(),
                About = _context.About.First(),
                Speakers=_context.Speakers,
                Events = _context.Events.OrderBy(e => e.Day),
            };

            return View(vm);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}