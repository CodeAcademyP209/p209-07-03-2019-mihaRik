﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P209_ASP_Front.DAL;
using P209_ASP_Front.Models;
using P209_ASP_Front.Extensions;
using static P209_ASP_Front.Utilities.Utilities;

namespace P209_ASP_Front.Areas.Admin.Controllers
{
    public class SpeakersController : Controller
    {
        private readonly EventreContext _context;

        public SpeakersController()
        {
            _context = new EventreContext();
        }
        // GET: Admin/Speakers
        public ActionResult Index()
        {
            return View(_context.Speakers);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Fullname, Profession, Photo, Facebook, Twitter, LinkedIn, Pinterest")]Speaker speaker)
        {
            if (!ModelState.IsValid) return View(speaker);

            if(speaker.Photo == null)
            {
                ModelState.AddModelError("Photo", "Şəkil yüklənməlidir.");
                return View(speaker);
            }

            if (!speaker.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Şəkil düzgün formatda deyil.");
                return View(speaker);
            }

            speaker.Image = speaker.ImageThumb = speaker.Photo.Save("speakers");

            _context.Speakers.Add(speaker);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        public ActionResult Delete(int? id)
        {
            if (id == null) return HttpNotFound();

            Speaker speaker = _context.Speakers.Find(id);

            if (speaker == null) return HttpNotFound();

            return View(speaker);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id)
        {
            Speaker speaker = _context.Speakers.Find(id);

            RemoveImage(speaker.Image);
            RemoveImage(speaker.ImageThumb);

            _context.Speakers.Remove(speaker);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}