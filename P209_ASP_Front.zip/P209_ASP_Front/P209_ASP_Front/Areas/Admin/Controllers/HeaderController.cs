﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P209_ASP_Front.DAL;
using P209_ASP_Front.Models;
using static P209_ASP_Front.Utilities.Utilities;
using P209_ASP_Front.Extensions;

namespace P209_ASP_Front.Areas.Admin.Controllers
{
    public class HeaderController : Controller
    {
        private readonly EventreContext _context;

        public HeaderController()
        {
            _context = new EventreContext();
        }
        // GET: Admin/Header
        public ActionResult Index()
        {
            return View(_context.Headers.First());
        }

        public ActionResult Edit()
        {
            return View(_context.Headers.First());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Edit([Bind(Include = "Id, Title, Photo, DatePlace")]Header header)
        {
            if (!ModelState.IsValid) return View(header);

            Header headerFromDb = _context.Headers.First();

            if(header.Photo != null)
            {
                if (!header.Photo.IsImage())
                {
                    ModelState.AddModelError("Photo", "Photo type is not valid");
                    header.Image = headerFromDb.Image;
                    return View(header);
                }

                //find old image from db, remove it, baby
                RemoveImage(headerFromDb.Image);

                //get new image, save it, change db image, baby
                headerFromDb.Image = header.Photo.Save("background");
            }

            headerFromDb.Title = header.Title;
            headerFromDb.DatePlace = header.DatePlace;

            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}