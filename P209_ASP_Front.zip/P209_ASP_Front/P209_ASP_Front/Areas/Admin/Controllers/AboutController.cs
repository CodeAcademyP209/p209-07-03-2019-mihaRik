﻿using P209_ASP_Front.DAL;
using P209_ASP_Front.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P209_ASP_Front.Extensions;
using static P209_ASP_Front.Utilities.Utilities;


namespace P209_ASP_Front.Areas.Admin.Controllers
{
    public class AboutController : Controller
    {
        // GET: Admin/About

        private readonly EventreContext _context;

        public AboutController()
        {
            _context = new EventreContext();
        }
        public ActionResult Index()
        {
            return View(_context.About.First());
        }
        
        public ActionResult Edit()
        {
            return View(_context.About.First());
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]        
        public ActionResult Edit([Bind(Include ="Id,Title,ContentUp,ContentDown,Photo")] About about)
        {
            if (!ModelState.IsValid) return View(about);
            About aboutFor = _context.About.First();

            if (about.Photo != null)
            {
                if (!about.Photo.IsImage())
                {
                    ModelState.AddModelError("Photo", "Photo type is invalid");
                    about.Image = aboutFor.Image;
                    return View(about);
                }
                RemoveImage(aboutFor.Image);

                aboutFor.Image = about.Photo.Save("speakers");                
            }
            aboutFor.ContentUp = about.ContentUp;
            aboutFor.ContentDown = about.ContentDown;
            aboutFor.Title = about.Title;

            _context.SaveChanges();

            return RedirectToAction("Index");
        }

    }
}