﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace P209_ASP_Front.Models
{
    public class Event
    {
        public Event()
        {
            Talks = new HashSet<Talk>();
        }

        public int Id { get; set; }
        public DateTime Day { get; set; }

        public virtual ICollection<Talk> Talks { get; set; }
    }
}